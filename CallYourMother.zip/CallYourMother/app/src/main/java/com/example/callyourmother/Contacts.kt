package com.example.callyourmother

import java.util.*

class Contacts(
    var image: String?,
    var phone: String?,
    var name: String?,
    var notification: String?,
    lastCallDate: Date
) {
    var lastCallDate: Date? = lastCallDate

}